define(function() {

    return new ENUM([
        'SMALL',
        'LARGE'
    ]);

});
