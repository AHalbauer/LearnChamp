<?php
$benutzer="root";
$pass="";
$db="matz";
$link=mysql_connect("localhost",$benutzer,$pass);
if (! $link)
die ("keine Verbindung zu mysql");
mysql_select_db ($db,$link)
or die ("Konnte $db nicht oeffnen".mysql_error());
$ergebnis=mysql_query("SELECT * FROM galerie");
?>
<html>
<head>
<title>Galerie</title>
</head>
<body align="center">
<TABLE style="margin: 0px auto;">
<?php
while ($rs=mysql_fetch_array($ergebnis)) {
?>
<tr>
<td><?=$rs['id'] ?></td>
<td><?=$rs['Titel']?></td>
<td><a onClick="javascript:return confirm('Sind Sie sicher?');" href="galerie_db_loeschen.php?id=<?=$rs['id']?>"> <img src="images/rotes_x.jpg" border="0"> </a></td>
<td><a href="galerie_bearbeiten.php?id=<?=$rs['id']?>"><img src="images/edit.jpg" border="0"> </a></td></tr>
<?php
}
?>
</TABLE>
<p><a href="galerie_einfuegen.html">Neues Foto anlegen</a></p>
</body>
</html>