<?php
session_start();
/****************************
1. Datenbankanbindung
*****************************/
$benutzer="root"; 
$pass=""; 
$db="matz"; 
$link=mysql_connect("localhost",$benutzer,$pass); 
if (! $link) 
        die ("keine Verbindung zu mysql"); 
mysql_select_db($db,$link) 
        or die ("Konnte $db nicht &ouml;ffnen".mysql_error());
/***************************************
2. SQL-Befehl an die Datenbank schicken
***************************************/
$ergebnis=mysql_query("SELECT * FROM benutzer WHERE benutzername LIKE '$_POST[benutzername]' AND kennwort LIKE '$_POST[kennwort]'");

if (mysql_num_rows($ergebnis)==1) { //eine Ergbniszeile, wenn Benutzername UND Kennwort richtig
while ($rs=mysql_fetch_array($ergebnis)) {
$_SESSION['benutzername']=$rs['benutzername'];
$_SESSION['id']=$rs['id'];
$_SESSION['vorname']=$rs['vorname'];
$_SESSION['zuname']=$rs['zuname'];
header('Location: geheim.php');
}
}
else {
echo "Benutzername und/oder Kennwort falsch";
echo "<br><a href='index.php'>Zur�ck</a>";
}
