      <a class="navbar-brand" href="#">Halbauer's Homepage</a>
    </div>

    <!-- Collect the nav links, forms, and other content for toggling -->
    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
      <ul class="nav navbar-nav">
        <li class="active"><a href="#">Home</a></li>
        <li class="dropdown">
          <a href="#" class="dropdown-toggle" data-toggle="dropdown">&Uuml;ber mich <b class="caret"></b></a>
          <ul class="dropdown-menu">
            <li><a href="#">Pers&ouml;nliche Daten</a></li>
            <li><a href="#">Schulbildung</a></li>
            <li><a href="#">Berufserfahrung</a></li>
            <li class="divider"></li>
            <li><a href="#">Privates</a></li>
          </ul>
        </li>
      </ul>
      
      
    </div><!-- /.navbar-collapse -->
  </div><!-- /.container-fluid -->
</nav>
</div><!-- Ende Container-->

<div class="container">
<div class="jumbotron">
<h1>Herzlich Willkommen auf meiner Homepage!</h1>
<p>Hier erfahren Sie mehr &Uuml;ber mich ...</p>

</div><!-- Ende Jumbotron-->
</div> <!-- Ende container--> 
<div class="container">
<div class="row">
  <div class="col-md-6">
		<div class="panel panel-default">
			<div class="panel-heading">&Uuml;berschirft links</div>
				<div class="panel-body">
					<p>Hier steht ein sinnbefreiter Blindtext.</p>
					<p>Hier steht ein sinnbefreiter Blindtext.</p>
					<p>Hier steht ein sinnbefreiter Blindtext.</p>
					<p>Hier steht ein sinnbefreiter Blindtext.</p>
					<p>Hier steht ein sinnbefreiter Blindtext.</p>
					<p>Hier steht ein sinnbefreiter Blindtext.</p>
				</div><!-- Ende panel-body-->
		</div><!-- Ende Panel -->
  </div><!-- Ende Col-md-6 -->
	<div class="col-md-6">
	<div class="panel panel-warning">
			<div class="panel-heading">&Uuml;berschirft rechts</div>
				<div class="panel-body">
					<p>Hier steht ein sinnbefreiter Blindtext.</p>
					<p>Hier steht ein sinnbefreiter Blindtext.</p>
					<p>Hier steht ein sinnbefreiter Blindtext.</p>
					<p>Hier steht ein sinnbefreiter Blindtext.</p>
					<p>Hier steht ein sinnbefreiter Blindtext.</p>
					<p>Hier steht ein sinnbefreiter Blindtext.</p>
				</div><!-- Ende panel-body-->
		</div><!-- Ende Panel -->
	
	
	</div><!-- Ende Col-md-6 -->
</div>

</div><!-- Ende Container-->
<div class="container">
<div class="input-group">
  <span class="input-group-addon">@</span>
  <input type="text" class="form-control" placeholder="Benutzername">
</div>
<div class="input-group">
  <span class="input-group-addon">
  <span class="glyphicon glyphicon-lock"></span>
  </span>
  <input type="text" class="form-control" placeholder="Passwort">
</div>
<div class="conatiner text-center">
  <button type="button" class="btn btn-primary">Anmelden</button>
 
  <button type="button" class="btn btn-danger">L&ouml;schen</button>
</div>

<div class="list-group">
<a class="list-group-item" href="http://orf.at"><span class="badge">23</span>Link zu orf.at</a>
<a class="list-group-item" href="http://derstandard.at">Link zu derStandard.at</a>
<a class="list-group-item" href="http://diepress.at">Link zu diePresse.at</a>
<a class="list-group-item active" href="http://pannoneum.at"><span class="badge">NEW</span>Link zu Pannoneum.at</a>

</div>

<nav class="navbar navbar-inverse navbar-fixed-bottom" role="navigation">
  <div class="container">
  <div class="text-center text-danger">Design by Astrid Halbauer, all rights to me
  </div>
</nav>


   <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>
  </body>
</html>