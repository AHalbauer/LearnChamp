<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
    "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<!--

	Vacant Snowdrift by nodethirtythree + Templated.org
	http://templated.org/ | @templatedorg
	Released under the Creative Commons Attribution 3.0 License.
	
	Note from the author: These templates take quite a bit of time to conceive,
	design, and finally code. So please, support our efforts by respecting our
	license: keep our footer credit links intact so people can find out about us
	and what we do. It's the right thing to do, and we'll love you for it :)
	
-->
<html xmlns="http://www.w3.org/1999/xhtml">
                           
    <head>
        <meta name="keywords" content="" />
        <meta name="description" content="" />
        <meta http-equiv="content-type" content="text/html; charset=utf-8" />
        <title>Matz der Maler</title>
        <link href="http://fonts.googleapis.com/css?family=Arvo" rel="stylesheet" type="text/css" />
        <link rel="stylesheet" type="text/css" href="style.css" />
        
<script type="text/javascript" src="js/jquery-1.9.1.min.js"></script>
<script type="text/javascript" src="js/jssor.slider.mini.js"></script>
<script>
    
        jQuery(document).ready(function ($) {
            //Reference http://www.jssor.com/development/slider-with-slideshow-jquery.html
            //Reference http://www.jssor.com/development/tool-slideshow-transition-viewer.html

            var _SlideshowTransitions = [
            //Fade
            { $Duration: 1200, $Opacity: 2 }
            ];

            var options = {
                $SlideDuration: 500,                                //[Optional] Specifies default duration (swipe) for slide in milliseconds, default value is 500
                $DragOrientation: 3,                                //[Optional] Orientation to drag slide, 0 no drag, 1 horizental, 2 vertical, 3 either, default value is 1 (Note that the $DragOrientation should be the same as $PlayOrientation when $DisplayPieces is greater than 1, or parking position is not 0)
                $AutoPlay: true,                                    //[Optional] Whether to auto play, to enable slideshow, this option must be set to true, default value is false
                $AutoPlayInterval: 1500,                            //[Optional] Interval (in milliseconds) to go for next slide since the previous stopped if the slider is auto playing, default value is 3000
                $SlideshowOptions: {                                //[Optional] Options to specify and enable slideshow or not
                    $Class: $JssorSlideshowRunner$,                 //[Required] Class to create instance of slideshow
                    $Transitions: _SlideshowTransitions,            //[Required] An array of slideshow transitions to play slideshow
                    $TransitionsOrder: 1,                           //[Optional] The way to choose transition to play slide, 1 Sequence, 0 Random
                    $ShowLink: true                                    //[Optional] Whether to bring slide link on top of the slider when slideshow is running, default value is false
                }
            };

            var jssor_slider1 = new $JssorSlider$("slider1_container", options);

        });
    
</script>
    </head>
    <body>
        <div id="bg">
            <div id="outer">
        
                <div id="banner">
                
                
            <!-- Slides Container -->
          <div id="slider1_container" style="position: relative; top: 0px; left: 0px;">
    <!-- Slides Container -->
    <div u="slides" style="cursor: move; position: absolute; overflow: hidden; left: 0px; top: 0px; width: 1116px; height: 200px;">
        <div><img u="image" src="images/1.jpg" /></div>
        <div><img u="image" src="images/2.jpg" /></div>
        <div><img u="image" src="images/3.jpg" /></div>
        <div><img u="image" src="images/4.jpg" /></div>
        <div><img u="image" src="images/5.jpg" /></div>
        <div><img u="image" src="images/6.jpg" /></div>
    </div>
</div>
        <!-- Jssor Slider End -->
	
				</div>
				<div id="main">
					<div id="content">
						<div id="box1">
						
							<h1>
								Feedback
							</h1>
							<br>
							<p>
						Werte Kundin, werter Kunde!<br>

Ihre Meinung ist uns wichtig!<br>

Helfen Sie uns bei der ständigen Verbesserung unserer Dienstleistungen.<br>

Ihr Feedback ermöglicht ein noch besseres Service für Sie!

							</p>
						</div>
						<div id="box2">
							<h3>
								
							</h3>
							<p>
							<form action="input_text.html">
  <div style="width:614px" class="wmfg_layout_0">

<form method="post" action="mailto:matzdermaler@aon.at">

<ul class="wmfg_questions">

	<li class="wmfg_q">
		<label class="wmfg_label" for="text_id">Was finden Sie besonders gut?</label>
		<input type="text" class="wmfg_text" name="text_name" id="text_id" value="" />
	</li>

	<li class="wmfg_q">
		<label class="wmfg_label" for="text_id">Was könnten wir verbessern?</label>
		<input type="text" class="wmfg_text" name="text_name" id="text_id" value="" />
	</li>

	<li class="wmfg_q">
		<label class="wmfg_label">Ausführung der Arbeit</label>
		<table class="wmfg_answers">
			<tr class="wmfg_a">
				<td class="wmfg_a_td"><input type="radio" class="wmfg_radio" name="nameradio" value="value 1" /></td>
				<td><label class="wmfg_label_a" for="radio_1">Sehr gut</label></td>
			</tr>
			<tr class="wmfg_a">
				<td class="wmfg_a_td"><input type="radio" class="wmfg_radio" name="nameradio" value="value 2" /></td>
				<td><label class="wmfg_label_a" for="radio_2">Gut</label></td>
			</tr>
			<tr class="wmfg_a">
				<td class="wmfg_a_td"><input type="radio" class="wmfg_radio" name="nameradio" value="value 3" /></td>
				<td><label class="wmfg_label_a" for="radio_3">Zufriedenstellend</label></td>
			</tr>
			<tr class="wmfg_a">
				<td class="wmfg_a_td"><input type="radio" class="wmfg_radio" name="nameradio" value="value 1" /></td>
				<td><label class="wmfg_label_a" for="radio_1">Weniger zufriedenstellend</label></td>
			</tr>
			<tr class="wmfg_a">
				<td class="wmfg_a_td"><input type="radio" class="wmfg_radio" name="nameradio" value="value 1" /></td>
				<td><label class="wmfg_label_a" for="radio_1">Nicht zufriedenstellend </label></td>
			</tr>
		</table>
	</li>

	<li class="wmfg_q">
		<label class="wmfg_label">Freundlichkeit </label>
		<table class="wmfg_answers">
			<tr class="wmfg_a">
				<td class="wmfg_a_td"><input type="radio" class="wmfg_radio" name="nameradio" value="value 1" /></td>
				<td><label class="wmfg_label_a" for="radio_1">Sehr freundlich</label></td>
			</tr>
			<tr class="wmfg_a">
				<td class="wmfg_a_td"><input type="radio" class="wmfg_radio" name="nameradio" value="value 2" /></td>
				<td><label class="wmfg_label_a" for="radio_2">Weniger freundlich</label></td>
			</tr>
			<tr class="wmfg_a">
				<td class="wmfg_a_td"><input type="radio" class="wmfg_radio" name="nameradio" value="value 3" /></td>
				<td><label class="wmfg_label_a" for="radio_3">Nicht freundlich</label></td>
			</tr>
		</table>
	</li>

	<li class="wmfg_q">
		<label class="wmfg_label">Beratung</label>
		<table class="wmfg_answers">
			<tr class="wmfg_a">
				<td class="wmfg_a_td"><input type="radio" class="wmfg_radio" name="nameradio" value="value 1" /></td>
				<td><label class="wmfg_label_a" for="radio_1">Sehr verständlich</label></td>
			</tr>
			<tr class="wmfg_a">
				<td class="wmfg_a_td"><input type="radio" class="wmfg_radio" name="nameradio" value="value 2" /></td>
				<td><label class="wmfg_label_a" for="radio_2">Weniger verständlich</label></td>
			</tr>
			<tr class="wmfg_a">
				<td class="wmfg_a_td"><input type="radio" class="wmfg_radio" name="nameradio" value="value 3" /></td>
				<td><label class="wmfg_label_a" for="radio_3">Nicht verständlich</label></td>
			</tr>
		</table>
	</li>

	<li class="wmfg_q">
		<label class="wmfg_label">Preis-Leistungs-Verhältnis</label>
		<table class="wmfg_answers">
			<tr class="wmfg_a">
				<td class="wmfg_a_td"><input type="radio" class="wmfg_radio" name="nameradio" value="value 1" /></td>
				<td><label class="wmfg_label_a" for="radio_1">Sehr gut</label></td>
			</tr>
			<tr class="wmfg_a">
				<td class="wmfg_a_td"><input type="radio" class="wmfg_radio" name="nameradio" value="value 2" /></td>
				<td><label class="wmfg_label_a" for="radio_2">Weniger gut</label></td>
			</tr>
			<tr class="wmfg_a">
				<td class="wmfg_a_td"><input type="radio" class="wmfg_radio" name="nameradio" value="value 3" /></td>
				<td><label class="wmfg_label_a" for="radio_3">Nicht gut</label></td>
			</tr>
		</table>
	</li>

	<li class="wmfg_q">
		<label class="wmfg_label">Sauberkeit</label>
		<table class="wmfg_answers">
			<tr class="wmfg_a">
				<td class="wmfg_a_td"><input type="radio" class="wmfg_radio" name="nameradio" value="value 1" /></td>
				<td><label class="wmfg_label_a" for="radio_1">Sehr sauber</label></td>
			</tr>
			<tr class="wmfg_a">
				<td class="wmfg_a_td"><input type="radio" class="wmfg_radio" name="nameradio" value="value 2" /></td>
				<td><label class="wmfg_label_a" for="radio_2">Weniger sauber</label></td>
			</tr>
			<tr class="wmfg_a">
				<td class="wmfg_a_td"><input type="radio" class="wmfg_radio" name="nameradio" value="value 3" /></td>
				<td><label class="wmfg_label_a" for="radio_3">Nicht sauber</label></td>
			</tr>
		</table>
	</li>

</ul>

</form>

</div>

  
  

  <p>  <input class="submit" type="submit" name="absenden" value="Feedback Absenden" /></p>
</form>	
							
						</div>
						<br class="clear" />
					</div>
					<div id="sidebar1">
					
						<h3>
						
						</h3>
						<?php include('nav.inc');?>
					</div>
	
					<br class="clear" />
				</div>
				
			<div id="copyright">
				&copy; Matz der Maler | Design: Matz der Maler + <a href="http://templated.org/">Templated.org</a>
			</div>
		</div>
    </body>
</html>
