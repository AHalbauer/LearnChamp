<?php
session_start();
if ($_SESSION['benutzername']=='') header('Location: anmeldeformular.html');
?>
<!DOCTYPE HTML>
<!--
	Autonomy by TEMPLATED
    templated.co @templatedco
    Released for free under the Creative Commons Attribution 3.0 license (templated.co/license)
-->

<html>
	<head>
		<title>Bearbeiten</title>
		 <link rel="stylesheet" type="text/css" href="style.css" />
		</noscript>
		<!--[if lte IE 8]><link rel="stylesheet" href="css/ie/v8.css" /><![endif]-->
		<!--[if lte IE 9]><link rel="stylesheet" href="css/ie/v9.css" /><![endif]-->
	</head>
	<body>

		<!-- Header -->
		<div id="header">
			<div class="container">
				
				<!-- Logo -->
				<div id="logo">
					<h1><a href="#">Daten bearbeiten:</a></h1>
				</div>
			
				<nav id="nav">
				<?php include('navigation.inc');?>
					</nav>

			</div>
		</div>
		<!-- Header -->

	

		
						<section>
							<header>
								
							</header>
							
							<h2><p align="center">GALERIE</p></h2>
				


<h1 align="center">Herzlich willkommen <?php echo $_SESSION['vorname']?> <?php echo $_SESSION['zuname']?></h2>

<p align="center">Sie sind eingeloggt als <?php echo $_SESSION['benutzername']?></p>



<p>
<?php include('galeriedb.php');?>
</p>

<a href="logout.php">Ausloggen</a>

							
						
												

		<!-- Copyright -->
		<div id="copyright">
			<div class="container">
				<p>designed by Johanna Matz und Astrid Halbauer - Maturaprojekt 2015</p>
			</div>
		</div>

	</body>
</html>