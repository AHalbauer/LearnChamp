<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
    "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<!--

	Vacant Snowdrift by nodethirtythree + Templated.org
	http://templated.org/ | @templatedorg
	Released under the Creative Commons Attribution 3.0 License.
	
	Note from the author: These templates take quite a bit of time to conceive,
	design, and finally code. So please, support our efforts by respecting our
	license: keep our footer credit links intact so people can find out about us
	and what we do. It's the right thing to do, and we'll love you for it :)
	
-->
<html xmlns="http://www.w3.org/1999/xhtml">
                           
    <head>
        <meta name="keywords" content="" />
        <meta name="description" content="" />
        <meta http-equiv="content-type" content="text/html; charset=utf-8" />
        <title>Matz der Maler</title>
        <link href="http://fonts.googleapis.com/css?family=Arvo" rel="stylesheet" type="text/css" />
        <link rel="stylesheet" type="text/css" href="style.css" />
        
<script type="text/javascript" src="js/jquery-1.9.1.min.js"></script>
<script type="text/javascript" src="js/jssor.slider.mini.js"></script>
<script>
    
        jQuery(document).ready(function ($) {
            //Reference http://www.jssor.com/development/slider-with-slideshow-jquery.html
            //Reference http://www.jssor.com/development/tool-slideshow-transition-viewer.html

            var _SlideshowTransitions = [
            //Fade
            { $Duration: 1200, $Opacity: 2 }
            ];

            var options = {
                $SlideDuration: 500,                                //[Optional] Specifies default duration (swipe) for slide in milliseconds, default value is 500
                $DragOrientation: 3,                                //[Optional] Orientation to drag slide, 0 no drag, 1 horizental, 2 vertical, 3 either, default value is 1 (Note that the $DragOrientation should be the same as $PlayOrientation when $DisplayPieces is greater than 1, or parking position is not 0)
                $AutoPlay: true,                                    //[Optional] Whether to auto play, to enable slideshow, this option must be set to true, default value is false
                $AutoPlayInterval: 1500,                            //[Optional] Interval (in milliseconds) to go for next slide since the previous stopped if the slider is auto playing, default value is 3000
                $SlideshowOptions: {                                //[Optional] Options to specify and enable slideshow or not
                    $Class: $JssorSlideshowRunner$,                 //[Required] Class to create instance of slideshow
                    $Transitions: _SlideshowTransitions,            //[Required] An array of slideshow transitions to play slideshow
                    $TransitionsOrder: 1,                           //[Optional] The way to choose transition to play slide, 1 Sequence, 0 Random
                    $ShowLink: true                                    //[Optional] Whether to bring slide link on top of the slider when slideshow is running, default value is false
                }
            };

            var jssor_slider1 = new $JssorSlider$("slider1_container", options);

        });
    
</script>
    </head>
    <body>
        <div id="bg">
            <div id="outer">
        
                <div id="banner">
                
                
            <!-- Slides Container -->
          <div id="slider1_container" style="position: relative; top: 0px; left: 0px;">
    <!-- Slides Container -->
    <div u="slides" style="cursor: move; position: absolute; overflow: hidden; left: 0px; top: 0px; width: 1116px; height: 200px;">
        <div><img u="image" src="images/1.jpg" /></div>
        <div><img u="image" src="images/2.jpg" /></div>
        <div><img u="image" src="images/3.jpg" /></div>
        <div><img u="image" src="images/4.jpg" /></div>
        <div><img u="image" src="images/5.jpg" /></div>
        <div><img u="image" src="images/6.jpg" /></div>
    </div>
</div>
        <!-- Jssor Slider End -->
	
				</div>
				<div id="main">
					<div id="content">
						<div id="box1">
						
								<h1>
								Restaurierung
							</h1>
							<br>
							<p>
							Eines unser Spezialgebiete ist die Restaurierung alter und neuer Objekte.<br>

							Wir helfen Ihnen geliebte und kostbare Gegenstände, wie</p>
							<p><b>
							Antiquitäten,
						    Möbel, Holzobjekte,
							Bilder, Rahmen<br>
						Figuren, Kirchenmalereien und denkmalgeschützte Objekte ...</p></b>
						
						<img class="left" src="images/rest1.jpg" width="150" height="150" alt="" /><img class="left" src="images/technik2.jpg" width="150" height="150" alt="" /><img class="left" src="images/rest.jpg" width="150" height="150" alt="" /><img class="left" src="images/rest4.jpg" width="150" height="150" alt="" />
						<br>
						<br>
						<br>
						<br>
						<br>
						<br>
						

							<p>
							..., zu bewahren und deren Erhaltungskriterien zu verbessern.<br>

							Unser Tätigkeitsgebiet erstreckt sich vom privaten Bereich und dem Bundesdenkmalamt 
							Wien und Umgebung bis hin zur Eremitage in St. Petersburg.<br>
							</p>

							<p><i>
							Der Kirchenmaler:     Neudorf, Parndorf, Pama, Neusiedl/See<br>
							Brandsanierung - Wasserschadensanierung<br>
							Bautrockengeräte - Luftentfeuchter<br>
							Schimmelpilzsanierung - Bekämpfung<br>
							</p></i>
							
							<h2>Mamor & Stuck</h2>
							<p>
							 Verschönern Sie Ihre Innenräume mit kunstvollen Stuckelementen aus feinster Gipsmischung oder mit täuschend echter Marmormalerei.
							 </p>
							 <img class="left" src="images/stuck.jpg" width="200" height="200" alt="" /><img class="left" src="images/stuck2.jpg" width="200" height="200" alt="" />
							 <br>
							 <br>
							 <br>
							 <br>
							 <br>
							 <br>
							 <br>
							 <p>
                             Veredelungen mit Marmor verleihen Ihren bereits bestehenden Bauteilen, wie kleineren Wandelementen, Fenstereinfassungen, 
							 Säulen und Türen, eine optische Tiefenwirkung und einen besonderen Glanz.
							 </p>
							 <img class="left" src="images/technik1.jpg" width="200" height="200" alt="" /><img class="left" src="images/technik3.jpg" width="200" height="200" alt="" /><img class="left" src="images/technik4.jpg" width="200" height="200" alt="" />
							 <br>
							 <br>
							 <br>
							 <br>
							 <br>
							 <br>
							 <br>
							 <p>
                             Dekorationen in bester Qualität, wie
							 </p>

                             <p><b>Gesimse, Zierleisten,<br>
                             Holzkehlen, Zierecken,<br>
                             Rosetten, Pilaster,<br>
							 Säulen und Umrahmungen</b></p>

							 <p>lassen Ihre vier Wände zu einer anspruchsvollen Wohnkultur werden.
							 Gerne realisieren wir auch Ihre eigenen Entwürfe.
							</p>
							
							<h2>Vergoldungen</h2>
							<p>
							<img class="left" src="images/gold1.jpg" width="200" height="200" alt="" />
							
							    Veredelung mit Stil - Gold verleiht Ihren Räumen und Gegenständen einen Hauch von Exklusivität.
                                Vergoldung kann zu Flächen- und Dekorationsarbeiten auf verschiedensten Materialien eingesetzt werden.

                                Egal ob es sich um Ornamente und Verzierungen auf Holz, Glas, Stein, Gips, Papier, Karton, Wachs, Porzellan, Keramik, 
								Ton, Folien oder lackierte Oberflächen handelt, Ihre Gegenstände werden mit Metallen bester Qualität veredelt – 
								mit echtem Blattgold, Blattmetallen, Blattsilber und Art-Metallen.
							</p>
							
							<h2>Fresko</h2>
							<p>
							   Als Fresko wird ein Wand- oder Deckengemälde bezeichnet, welches aus der sogenannten Freskomalerei, 
							   einer spezifischen Form der Wandmalerei, entsteht.</p>

							   <img class="left" src="images/fresko1.jpg" width="200" height="200" alt="" /><img class="left" src="images/fresko2.jpg" width="200" height="200" alt="" />
							   
                               <p>Die Farben werden auf den frischen Putz aufgetragen und verbinden sich unlöslich mit dem Untergrund. 
							   Hierbei wird zwischen der al secco- und der al fresco-Malerei unterschieden, je nachdem, welche Konsistenz der 
							   Wandputz aufweist.</p>

                               <p>Bei der al fresco-Malweise werden mit Wasser angerührte Farbpigmente auf den feuchten, bindungsfähigen Putz aufgetragen, 
							   sodass sich die Kalkteilchen im Putz mit jenen der Farbe vermengen können.</p>

                               <p>Dadurch kommt beim Trocknen eine Kalkputzschicht mit eingearbeiteter Farbe zum Vorschein. 
							   Im Gegensatz dazu wir die Farbe bei der al secco-Malerei auf die trockene Wand verteilt. 
							</p>
						</div>
						<div id="box2">
							<h3>
								
							</h3>
							<p>
								
							
						</div>
						<br class="clear" />
					</div>
					<div id="sidebar1">
					
						<h3>
							
						</h3>
						<?php include('nav.inc');?>
					</div>
	
					<br class="clear" />
				</div>
				
			<div id="copyright">
				&copy; Matz der Maler | Design: Matz der Maler + <a href="http://templated.org/">Templated.org</a>
			</div>
		</div>
    </body>
</html>
