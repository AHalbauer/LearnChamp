<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
    "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<!--

	Vacant Snowdrift by nodethirtythree + Templated.org
	http://templated.org/ | @templatedorg
	Released under the Creative Commons Attribution 3.0 License.
	
	Note from the author: These templates take quite a bit of time to conceive,
	design, and finally code. So please, support our efforts by respecting our
	license: keep our footer credit links intact so people can find out about us
	and what we do. It's the right thing to do, and we'll love you for it :)
	
-->
<html xmlns="http://www.w3.org/1999/xhtml">
    <head>
        <meta name="keywords" content="" />
        <meta name="description" content="" />
        <meta http-equiv="content-type" content="text/html; charset=utf-8" />
		<title>Matz der Maler</title>
        <link href="http://fonts.googleapis.com/css?family=Arvo" rel="stylesheet" type="text/css" />
		<link rel="stylesheet" type="text/css" href="style.css" />
    </head>
    <body>
		<div id="bg">
			<div id="outer">
				<div id="header">
					<div id="logo">
						<h1>
							<a href="#">Matz der Maler</a>
						</h1>
					</div>
					<div id="nav">
						<ul>
							<li class="first active">
								<a href="index.php">Home</a>
							</li>
							<li>
								<a href="kontakt.php">Kontakt</a>
							</li>
							<li class="last">
								<a href="impressum.php">Impressum</a>
							</li>
						</ul>
						<br class="clear" />
					</div>
				</div>
				<div id="banner">
					<img src="images/pic1.jpg" width="1120" height="200" alt="" />
				</div>
				<div id="main">
					<div id="content">
						<div id="box1">
							<h2>
								Fresko
							</h2>
							<p>
							   Als Fresko wird ein Wand- oder Deckengemälde bezeichnet, welches aus der sogenannten Freskomalerei, 
							   einer spezifischen Form der Wandmalerei, entsteht.</p>

                               <p>Die Farben werden auf den frischen Putz aufgetragen und verbinden sich unlöslich mit dem Untergrund. 
							   Hierbei wird zwischen der al secco- und der al fresco-Malerei unterschieden, je nachdem, welche Konsistenz der 
							   Wandputz aufweist.</p>

                               <p>Bei der al fresco-Malweise werden mit Wasser angerührte Farbpigmente auf den feuchten, bindungsfähigen Putz aufgetragen, 
							   sodass sich die Kalkteilchen im Putz mit jenen der Farbe vermengen können.</p>

                               <p>Dadurch kommt beim Trocknen eine Kalkputzschicht mit eingearbeiteter Farbe zum Vorschein. 
							   Im Gegensatz dazu wir die Farbe bei der al secco-Malerei auf die trockene Wand verteilt. 
							</p>
						</div>
						
						<br class="clear" />
					</div>
					<div id="sidebar1">
					
						<h3>
							menü
						</h3>
						<?php include('nav.inc');?>
					</div>
	
					<br class="clear" />
				</div>
				<div id="footer">
					<div id="footerContent">
						<h3>
							
						</h3>
						
					</div>
					<div id="footerSidebar1">
						<h3>
							<p>Firma Michael Matz jun.</p> <p>Gartenweg 126</p> <p>7100 Neusiedl am See</p> <p>0664/9184218</p> <p>matzdermaler@aon.at</p>
						</h3>
					
					</div>
				
					<br class="clear" />
				</div>
			</div>
			<div id="copyright">
				&copy; Matz der Maler | Design: <a href="http://templated.org/free-css-templates/vacantsnowdrift/">Matz der Maler</a> by <a href="http://nodethirtythree.com">Halbauer & Matz</a> + <a href="http://templated.org/">Templated.org</a>
			</div>
		</div>
    </body>
</html>