<!DOCTYPE HTML>
<!--
	Autonomy by TEMPLATED
    templated.co @templatedco
    Released for free under the Creative Commons Attribution 3.0 license (templated.co/license)
-->

<html>
	<head>
		<title>Aktionen</title>
		<meta http-equiv="content-type" content="text/html; charset=utf-8" />
		<meta name="description" content="" />
		<meta name="keywords" content="" />
		<link href='http://fonts.googleapis.com/css?family=Raleway:400,100,200,300,500,600,700,800,900' rel='stylesheet' type='text/css'>
		<!--[if lte IE 8]><script src="js/html5shiv.js"></script><![endif]-->
		<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
		<script src="js/skel.min.js"></script>
		<!--<script src="js/skel-panels.min.js"></script>
		WEGEN DER NAV in der MOBILEN ANSICHT!!!!!-->    
		<script src="js/init.js"></script>
		<noscript>
			<link rel="stylesheet" href="css/skel-noscript.css" />
			<link rel="stylesheet" href="css/style.css" />
			<link rel="stylesheet" href="css/style-desktop.css" />
		</noscript>
		<!--[if lte IE 8]><link rel="stylesheet" href="css/ie/v8.css" /><![endif]-->
		<!--[if lte IE 9]><link rel="stylesheet" href="css/ie/v9.css" /><![endif]-->
	</head>
	<body>

		<!-- Header -->
		<div id="header">
			<div class="container">
				
				<!-- Logo -->
				<div id="logo">
					<h1><a href="#">Aktionen</a></h1>
				</div>
				
				

			</div>
		</div>
		<!-- Header -->

	

		<div id="featured">
			<div class="container">
				<div class="row">
					<div class="12u">
						<section>
							<header>
								
							</header>
							
							<h2><p align="center">Aktion wurde in der Datenbank gespeichert</p></h2>
<?php
$benutzer="root";
$pass="";
$db="matz";
$link=mysql_connect("localhost",$benutzer,$pass);
if (! $link)
die ("keine Verbindung zu mysql");
mysql_select_db ($db,$link)
or die ("Konnte $db nicht oeffnen".mysql_error());
$ergebnis=mysql_query("UPDATE  aktionen SET bezeichnung='$_POST[bezeichnung]',beschreibung='$_POST[beschreibung]',zeitraum='$_POST[zeitraum]',preis='$_POST[preis]',id='$_POST[id]' WHERE id='$_POST[id]");
?>

<a href="geheim_2.php"><p align="center"> Zur&uuml;ck zur Liste</a></p>





							
							</div>
								
									</div>
										</div>
											</div>
												</div>
												

		<!-- Copyright -->
		<div id="copyright">
			<div class="container">
				<p>designed by Johanna Matz und Astrid Halbauer - Maturaprojekt 2015</p>
			</div>
		</div>

	</body>
</html>
